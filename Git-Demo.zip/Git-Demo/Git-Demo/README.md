
#Demo

Commands include -
clone,
add,
push,
origin master,
remote,
ls -la,
gh command
